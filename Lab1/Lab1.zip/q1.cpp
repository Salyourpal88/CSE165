#include <iostream> 

using namespace std;

main(){
    cout << "Hi, my name is Salvador Ruiz-Ramirez" << endl;
}