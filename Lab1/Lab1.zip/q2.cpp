#define _USE_MATH_DEFINES
#include <iostream> 
#include <cmath>

using namespace std;

main(){
    int Radius;
    cout << "Input Radius: " << endl;
    cin >> Radius;
    cout << "Area of the circle: "<< M_PI * pow(Radius, 2) << endl;
}