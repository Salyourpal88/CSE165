#include "LinkedList.h"
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main(){
    LinkedList myList();
    
}