#ifndef Refs_H
#define Refs_H
#include <iostream>
#include <vector>

using namespace std;

void triple(int &num){
    num = num * 3;
};
#endif